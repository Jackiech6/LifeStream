"""Lambda entry point for API - redirects to api.lambda_handler."""
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.api.lambda_handler import lambda_handler

# Export for Lambda
__all__ = ["lambda_handler"]
